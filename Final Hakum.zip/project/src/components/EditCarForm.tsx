import React, { useState, useEffect } from 'react';
import { useQueue } from '../context/QueueContext';
import { Car, CAR_SIZES, SERVICE_STATUSES } from '../types';

interface EditCarFormProps {
  car: Car;
  onComplete: () => void;
}

const EditCarForm: React.FC<EditCarFormProps> = ({ car, onComplete }) => {
  const { updateCar, services, crews } = useQueue();
  const [formData, setFormData] = useState({
    plate: car.plate,
    model: car.model,
    size: car.size,
    service: car.service,
    status: car.status,
    phone: car.phone || '',
    crew: car.crew || [],
    selectedServices: car.services || [],
    total_cost: car.total_cost || 0,
  });
  const [servicePrices, setServicePrices] = useState<Record<string, number>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const [isCrewOpen, setIsCrewOpen] = useState(false);

  useEffect(() => {
    // Initialize service prices from existing services or car's current pricing
    const prices: Record<string, number> = {};
    services.forEach(service => {
      prices[service.id] = service.price;
    });
    setServicePrices(prices);
  }, [services]);

  useEffect(() => {
    calculateTotalCost();
  }, [formData.selectedServices, servicePrices]);

  const calculateTotalCost = () => {
    const total = formData.selectedServices.reduce((sum, serviceId) => {
      return sum + (servicePrices[serviceId] || 0);
    }, 0);
    setFormData(prev => ({ ...prev, total_cost: total }));
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.plate.trim()) {
      newErrors.plate = 'License plate is required';
    } else if (!/^[A-Z]{2,3}[\s-]?\d{3,4}$/.test(formData.plate.toUpperCase())) {
      newErrors.plate = 'Please enter a valid Philippine license plate';
    }
    
    if (!formData.model.trim()) {
      newErrors.model = 'Car model is required';
    }

    // Phone number is optional, but if provided, validate format
    if (formData.phone.trim()) {
      const phoneRegex = /^(\+63|0)[\d\s]{10,12}$/;
      if (!phoneRegex.test(formData.phone.replace(/\s/g, ''))) {
        newErrors.phone = 'Please enter a valid Philippine phone number';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    let formattedValue = value;

    // Format license plate while typing
    if (name === 'plate') {
      formattedValue = value.toUpperCase();
    }

    // Format phone number while typing
    if (name === 'phone') {
      formattedValue = value.replace(/[^\d+]/g, '');
      if (formattedValue.startsWith('+63') && formattedValue.length > 3) {
        formattedValue = `+63 ${formattedValue.slice(3).match(/.{1,3}/g)?.join(' ')}`;
      } else if (formattedValue.startsWith('0') && formattedValue.length > 1) {
        formattedValue = `${formattedValue.slice(0, 4)} ${formattedValue.slice(4, 7)} ${formattedValue.slice(7, 11)}`;
      }
    }

    setFormData(prev => ({ ...prev, [name]: formattedValue }));
    
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleServiceToggle = (serviceId: string) => {
    setFormData(prev => ({
      ...prev,
      selectedServices: prev.selectedServices.includes(serviceId)
        ? prev.selectedServices.filter(id => id !== serviceId)
        : [...prev.selectedServices, serviceId]
    }));
  };

  const handleCrewToggle = (crewMember: string) => {
    setFormData(prev => ({
      ...prev,
      crew: prev.crew.includes(crewMember)
        ? prev.crew.filter(member => member !== crewMember)
        : [...prev.crew, crewMember]
    }));
  };

  const handlePriceChange = (serviceId: string, newPrice: number) => {
    setServicePrices(prev => ({
      ...prev,
      [serviceId]: newPrice
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validate()) {
      try {
        setIsSubmitting(true);
        const selectedServiceNames = formData.selectedServices.map(id => {
          const service = services.find(s => s.id === id);
          return service?.name || '';
        });

        // Only send fields that exist in the database schema
        await updateCar(car.id, {
          plate: formData.plate,
          model: formData.model,
          size: formData.size,
          status: formData.status,
          phone: formData.phone || 'Not provided',
          crew: formData.crew,
          service: selectedServiceNames.join(', '),
          services: formData.selectedServices,
          total_cost: formData.total_cost,
        });
        onComplete();
      } catch (error) {
        console.error('Error updating car:', error);
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <h2 className="text-xl font-bold text-white">Edit Vehicle</h2>
      
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <div>
          <label htmlFor="plate" className="block text-sm font-medium text-gray-300 mb-1">
            License Plate *
          </label>
          <input
            type="text"
            id="plate"
            name="plate"
            value={formData.plate}
            onChange={handleChange}
            className={`block w-full rounded-md shadow-sm sm:text-sm p-2 bg-gray-900 border ${
              errors.plate ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : 'border-gray-700 focus:ring-blue-500 focus:border-blue-500'
            } text-white`}
            disabled={isSubmitting}
          />
          {errors.plate && <p className="mt-1 text-sm text-red-400">{errors.plate}</p>}
        </div>

        <div>
          <label htmlFor="model" className="block text-sm font-medium text-gray-300 mb-1">
            Car Model *
          </label>
          <input
            type="text"
            id="model"
            name="model"
            value={formData.model}
            onChange={handleChange}
            className={`block w-full rounded-md shadow-sm sm:text-sm p-2 bg-gray-900 border ${
              errors.model ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : 'border-gray-700 focus:ring-blue-500 focus:border-blue-500'
            } text-white`}
            disabled={isSubmitting}
          />
          {errors.model && <p className="mt-1 text-sm text-red-400">{errors.model}</p>}
        </div>

        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-gray-300 mb-1">
            Phone Number <span className="text-gray-500">(optional)</span>
          </label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            placeholder="e.g., 0912 345 6789"
            className={`block w-full rounded-md shadow-sm sm:text-sm p-2 bg-gray-900 border ${
              errors.phone ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : 'border-gray-700 focus:ring-blue-500 focus:border-blue-500'
            } text-white placeholder-gray-400`}
            disabled={isSubmitting}
          />
          {errors.phone && <p className="mt-1 text-sm text-red-400">{errors.phone}</p>}
        </div>

        <div>
          <label htmlFor="size" className="block text-sm font-medium text-gray-300 mb-1">
            Car Size
          </label>
          <select
            id="size"
            name="size"
            value={formData.size}
            onChange={handleChange}
            className="block w-full rounded-md shadow-sm sm:text-sm p-2 bg-gray-900 border border-gray-700 text-white focus:ring-blue-500 focus:border-blue-500"
            disabled={isSubmitting}
          >
            {CAR_SIZES.map(size => (
              <option key={size.value} value={size.value}>
                {size.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="status" className="block text-sm font-medium text-gray-300 mb-1">
            Status
          </label>
          <select
            id="status"
            name="status"
            value={formData.status}
            onChange={handleChange}
            className="block w-full rounded-md shadow-sm sm:text-sm p-2 bg-gray-900 border border-gray-700 text-white focus:ring-blue-500 focus:border-blue-500"
            disabled={isSubmitting}
          >
            {SERVICE_STATUSES.map(status => (
              <option key={status.value} value={status.value}>
                {status.label}
              </option>
            ))}
          </select>
        </div>

        <div className="sm:col-span-2">
          <label className="block text-sm font-medium text-gray-300 mb-1">
            Services
          </label>
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsServicesOpen(!isServicesOpen)}
              className="w-full text-left p-2 bg-gray-900 border border-gray-700 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {formData.selectedServices.length === 0 ? (
                <span className="text-gray-400">Select services...</span>
              ) : (
                <span>{formData.selectedServices.length} services selected</span>
              )}
            </button>
            
            {isServicesOpen && (
              <div className="absolute z-10 w-full mt-1 bg-gray-900 border border-gray-700 rounded-md shadow-lg max-h-60 overflow-auto">
                {services.map(service => (
                  <div
                    key={service.id}
                    className="p-2 hover:bg-gray-800 cursor-pointer"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          checked={formData.selectedServices.includes(service.id)}
                          onChange={() => handleServiceToggle(service.id)}
                          className="h-4 w-4 text-blue-600 bg-gray-900 border-gray-700 rounded focus:ring-blue-500"
                        />
                        <span className="ml-2 text-white">{service.name}</span>
                      </div>
                    </div>
                    <div className="ml-6 flex items-center gap-2">
                      <span className="text-gray-400 text-sm">₱</span>
                      <input
                        type="number"
                        value={servicePrices[service.id] || 0}
                        onChange={(e) => handlePriceChange(service.id, Number(e.target.value))}
                        className="w-20 px-2 py-1 text-sm bg-gray-800 border border-gray-600 rounded text-white focus:ring-blue-500 focus:border-blue-500"
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="sm:col-span-2">
          <label className="block text-sm font-medium text-gray-300 mb-1">
            Assign Crew
          </label>
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsCrewOpen(!isCrewOpen)}
              className="w-full text-left p-2 bg-gray-900 border border-gray-700 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {formData.crew.length === 0 ? (
                <span className="text-gray-400">Select crew members...</span>
              ) : (
                <span>{formData.crew.length} crew members selected</span>
              )}
            </button>
            
            {isCrewOpen && (
              <div className="absolute z-10 w-full mt-1 bg-gray-900 border border-gray-700 rounded-md shadow-lg max-h-60 overflow-auto">
                {crews.map(member => (
                  <div
                    key={member}
                    className="p-2 hover:bg-gray-800 cursor-pointer flex items-center"
                    onClick={() => handleCrewToggle(member)}
                  >
                    <input
                      type="checkbox"
                      checked={formData.crew.includes(member)}
                      onChange={() => {}}
                      className="h-4 w-4 text-blue-600 bg-gray-900 border-gray-700 rounded focus:ring-blue-500"
                    />
                    <span className="ml-2 text-white">{member}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="sm:col-span-2">
          <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
            <div className="flex justify-between items-center">
              <span className="text-lg font-medium text-gray-300">Selected Services:</span>
            </div>
            <div className="mt-2 space-y-2">
              {formData.selectedServices.map(serviceId => {
                const service = services.find(s => s.id === serviceId);
                return service ? (
                  <div key={service.id} className="flex justify-between text-sm">
                    <span className="text-gray-400">{service.name}</span>
                    <span className="text-white">₱{(servicePrices[serviceId] || 0).toLocaleString()}</span>
                  </div>
                ) : null;
              })}
              <div className="pt-2 border-t border-gray-600 flex justify-between items-center">
                <span className="text-lg font-medium text-gray-300">Total:</span>
                <span className="text-2xl font-bold text-blue-500">₱{formData.total_cost.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-end space-x-3">
        <button
          type="button"
          onClick={onComplete}
          className="inline-flex items-center px-4 py-2 border border-gray-700 shadow-sm text-sm font-medium rounded-md text-gray-300 bg-gray-900 hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          disabled={isSubmitting}
        >
          Cancel
        </button>
        <button
          type="submit"
          className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          disabled={isSubmitting}
        >
          {isSubmitting ? 'Saving...' : 'Save Changes'}
        </button>
      </div>
    </form>
  );
};

export default EditCarForm;