import React, { useState } from 'react';
import { useQueue } from '../context/QueueContext';
import { Service } from '../types';
import { Plus, Edit2, Trash2 } from 'lucide-react';

const ServicesPage: React.FC = () => {
  const { services, addService, updateService, deleteService } = useQueue();
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    price: 0,
    description: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingService) {
        await updateService(editingService.id, formData);
        setEditingService(null);
      } else {
        await addService(formData);
        setShowAddForm(false);
      }
      setFormData({ name: '', price: 0, description: '' });
    } catch (error) {
      console.error('Error saving service:', error);
    }
  };

  const handleEdit = (service: Service) => {
    setEditingService(service);
    setFormData({
      name: service.name,
      price: service.price,
      description: service.description || '',
    });
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteService(id);
    } catch (error) {
      console.error('Error deleting service:', error);
    }
  };

  const ServiceForm = () => (
    <form onSubmit={handleSubmit} className="bg-gray-900 p-6 rounded-lg shadow-sm border border-gray-800 mb-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-300">
            Service Name
          </label>
          <input
            type="text"
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="mt-1 block w-full rounded-md bg-gray-800 border border-gray-700 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm text-white"
            required
          />
        </div>
        <div>
          <label htmlFor="price" className="block text-sm font-medium text-gray-300">
            Price (PHP)
          </label>
          <input
            type="number"
            id="price"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
            className="mt-1 block w-full rounded-md bg-gray-800 border border-gray-700 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm text-white"
            min="0"
            required
          />
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="description" className="block text-sm font-medium text-gray-300">
            Description
          </label>
          <textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="mt-1 block w-full rounded-md bg-gray-800 border border-gray-700 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm text-white"
            rows={3}
          />
        </div>
      </div>
      <div className="mt-4 flex justify-end space-x-2">
        <button
          type="button"
          onClick={() => {
            setShowAddForm(false);
            setEditingService(null);
            setFormData({ name: '', price: 0, description: '' });
          }}
          className="inline-flex items-center px-4 py-2 border border-gray-700 shadow-sm text-sm font-medium rounded-md text-gray-300 bg-gray-800 hover:bg-gray-700"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
        >
          {editingService ? 'Update Service' : 'Add Service'}
        </button>
      </div>
    </form>
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-white">Services Management</h1>
          <p className="text-gray-400">Add, edit, or remove services</p>
        </div>
        {!showAddForm && !editingService && (
          <button
            onClick={() => setShowAddForm(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="h-5 w-5 mr-2" />
            Add Service
          </button>
        )}
      </div>

      {(showAddForm || editingService) && <ServiceForm />}

      <div className="bg-gray-900 shadow overflow-hidden sm:rounded-md border border-gray-800">
        <ul className="divide-y divide-gray-800">
          {services.map((service) => (
            <li key={service.id} className="px-6 py-4 hover:bg-gray-800">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-white">{service.name}</h3>
                  <p className="text-sm text-gray-400">{service.description}</p>
                  <p className="text-lg font-semibold text-blue-400">
                    ₱{service.price.toLocaleString()}
                  </p>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleEdit(service)}
                    className="inline-flex items-center p-2 border border-gray-700 rounded-md text-gray-300 bg-gray-800 hover:bg-gray-700"
                  >
                    <Edit2 className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(service.id)}
                    className="inline-flex items-center p-2 border border-transparent rounded-md text-white bg-red-600 hover:bg-red-700"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default ServicesPage;