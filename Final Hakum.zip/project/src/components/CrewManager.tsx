import React, { useState } from 'react';
import { useQueue } from '../context/QueueContext';
import { UserPlus, Trash2 } from 'lucide-react';

const CrewManager: React.FC = () => {
  const { crews, addCrew, removeCrew } = useQueue();
  const [newCrewMember, setNewCrewMember] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCrewMember.trim()) {
      setError('Crew member name is required');
      return;
    }
    addCrew(newCrewMember.trim());
    setNewCrewMember('');
    setError('');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Crew Management</h1>
          <p className="text-gray-400">Add or remove crew members</p>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-lg font-medium text-gray-400">{crews.length} Members</span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="flex gap-4">
        <div className="flex-1">
          <input
            type="text"
            value={newCrewMember}
            onChange={(e) => setNewCrewMember(e.target.value)}
            placeholder="Enter crew member name"
            className={`block w-full rounded-md shadow-sm sm:text-sm p-2 bg-gray-900 border ${
              error ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : 'border-gray-700 focus:ring-blue-500 focus:border-blue-500'
            } text-white placeholder-gray-400`}
          />
          {error && <p className="mt-1 text-sm text-red-400">{error}</p>}
        </div>
        <button
          type="submit"
          className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          <UserPlus className="h-4 w-4 mr-2" />
          Add Member
        </button>
      </form>

      <div className="bg-gray-900 shadow overflow-hidden sm:rounded-md border border-gray-800">
        <ul className="divide-y divide-gray-800">
          {crews.map((member, index) => (
            <li key={index} className="px-6 py-4 flex items-center justify-between hover:bg-gray-800">
              <span className="text-sm font-medium text-white">{member}</span>
              <button
                onClick={() => removeCrew(member)}
                className="inline-flex items-center p-1.5 border border-transparent rounded-full text-red-400 hover:bg-red-900/20 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default CrewManager;