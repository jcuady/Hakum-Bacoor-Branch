import React, { createContext, useContext, useState, useEffect } from 'react';
import { Car, Service } from '../types';
import { supabase } from '../lib/supabase';

interface QueueContextType {
  cars: Car[];
  services: Service[];
  crews: string[];
  loading: boolean;
  error: string | null;
  addCar: (car: Omit<Car, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
  updateCar: (id: string, updates: Partial<Car>) => Promise<void>;
  removeCar: (id: string) => Promise<void>;
  addCrew: (name: string) => void;
  removeCrew: (name: string) => void;
  addService: (service: Omit<Service, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
  updateService: (id: string, updates: Partial<Service>) => Promise<void>;
  deleteService: (id: string) => Promise<void>;
}

const QueueContext = createContext<QueueContextType | undefined>(undefined);

export const QueueProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cars, setCars] = useState<Car[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [crews, setCrews] = useState<string[]>([
    'John Doe',
    'Jane Smith',
    'Mike Johnson',
    'Sarah Williams',
    'David Brown',
    'Lisa Davis',
    'Robert Wilson',
    'Emily Taylor',
  ]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchCars();
    fetchServices();

    const carsChannel = supabase
      .channel('cars-channel')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'cars' },
        () => fetchCars()
      )
      .subscribe();

    const servicesChannel = supabase
      .channel('services-channel')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'services' },
        () => fetchServices()
      )
      .subscribe();

    return () => {
      carsChannel.unsubscribe();
      servicesChannel.unsubscribe();
    };
  }, []);

  const fetchCars = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error } = await supabase
        .from('cars')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      // Transform the data to ensure proper types
      const transformedCars = (data || []).map(car => ({
        ...car,
        services: car.services || [],
        crew: car.crew || [],
        total_cost: car.total_cost || 0,
        created_at: car.created_at || new Date().toISOString(),
        updated_at: car.updated_at || new Date().toISOString(),
      }));
      
      setCars(transformedCars);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred';
      console.error('Error fetching cars:', err);
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const fetchServices = async () => {
    try {
      const { data, error } = await supabase
        .from('services')
        .select('*')
        .order('name', { ascending: true });

      if (error) throw error;
      setServices(data || []);
    } catch (err) {
      console.error('Error fetching services:', err);
    }
  };

  const addCar = async (car: Omit<Car, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      setError(null);
      const { error } = await supabase
        .from('cars')
        .insert([{
          plate: car.plate,
          model: car.model,
          size: car.size,
          service: car.service,
          status: car.status,
          phone: car.phone,
          crew: car.crew || [],
          services: car.services || [],
          total_cost: car.total_cost || 0,
        }])
        .select()
        .single();

      if (error) throw error;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to add car';
      console.error('Error adding car:', err);
      setError(errorMessage);
      throw err;
    }
  };

  const updateCar = async (id: string, updates: Partial<Car>) => {
    try {
      setError(null);
      const { error } = await supabase
        .from('cars')
        .update({ 
          ...updates, 
          updated_at: new Date().toISOString() 
        })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update car';
      console.error('Error updating car:', err);
      setError(errorMessage);
      throw err;
    }
  };

  const removeCar = async (id: string) => {
    try {
      setError(null);
      const { error } = await supabase
        .from('cars')
        .delete()
        .eq('id', id);

      if (error) throw error;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to remove car';
      console.error('Error removing car:', err);
      setError(errorMessage);
      throw err;
    }
  };

  const addService = async (service: Omit<Service, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      const { error } = await supabase
        .from('services')
        .insert([service])
        .select()
        .single();

      if (error) throw error;
    } catch (err) {
      console.error('Error adding service:', err);
      throw err;
    }
  };

  const updateService = async (id: string, updates: Partial<Service>) => {
    try {
      const { error } = await supabase
        .from('services')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
    } catch (err) {
      console.error('Error updating service:', err);
      throw err;
    }
  };

  const deleteService = async (id: string) => {
    try {
      const { error } = await supabase
        .from('services')
        .delete()
        .eq('id', id);

      if (error) throw error;
    } catch (err) {
      console.error('Error deleting service:', err);
      throw err;
    }
  };

  const addCrew = (name: string) => {
    if (!crews.includes(name)) {
      setCrews([...crews, name]);
    }
  };

  const removeCrew = (name: string) => {
    setCrews(crews.filter(crew => crew !== name));
  };

  return (
    <QueueContext.Provider value={{ 
      cars, 
      services,
      crews,
      loading, 
      error, 
      addCar, 
      updateCar, 
      removeCar,
      addCrew,
      removeCrew,
      addService,
      updateService,
      deleteService
    }}>
      {children}
    </QueueContext.Provider>
  );
};

export const useQueue = () => {
  const context = useContext(QueueContext);
  if (context === undefined) {
    throw new Error('useQueue must be used within a QueueProvider');
  }
  return context;
};